<?php

return [
	
	'tracker'	=>	['namespace' => 'Tracker'],
	'sites'		=>	['namespace' => 'Sites']
	
];

?>